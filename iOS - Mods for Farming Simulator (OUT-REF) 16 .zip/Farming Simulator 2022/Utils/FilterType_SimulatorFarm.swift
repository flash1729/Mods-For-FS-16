//
//  FilterType_SimulatorFarm.swift
//  Farming Simulator 2022
//
//  Created by Systems
//

import Foundation

enum FilterType_SimulatorFarm {
    case all
    case new
    case favorite
    case top
}
