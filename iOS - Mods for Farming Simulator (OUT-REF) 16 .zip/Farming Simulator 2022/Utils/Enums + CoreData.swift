//
//  Enums + CoreData.swift
//  Farming Simulator 2022
//
//  Created by Systems
//

import Foundation

